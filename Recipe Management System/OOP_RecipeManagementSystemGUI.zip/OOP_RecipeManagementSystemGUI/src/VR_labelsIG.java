import javax.swing.SwingConstants;

public class VR_labelsIG extends VR_labels {

	public VR_labelsIG() {
		super();
		setHorizontalAlignment(SwingConstants.CENTER);
	}
}
