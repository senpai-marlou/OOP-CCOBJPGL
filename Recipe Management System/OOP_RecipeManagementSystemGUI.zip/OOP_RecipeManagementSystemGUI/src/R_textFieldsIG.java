import javax.swing.SwingConstants;

public class R_textFieldsIG extends R_textFields {

	public R_textFieldsIG() {
		super();
		setHorizontalAlignment(SwingConstants.CENTER);
	}
}
