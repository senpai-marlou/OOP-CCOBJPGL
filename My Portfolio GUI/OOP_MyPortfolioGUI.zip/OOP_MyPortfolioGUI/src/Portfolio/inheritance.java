package Portfolio;

public class inheritance extends socialsButton {

	public inheritance() {
		super();
	}

}
